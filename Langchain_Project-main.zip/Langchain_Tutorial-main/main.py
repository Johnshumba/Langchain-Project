def main():
    print("Hello from langchain-tutorial!")


if __name__ == "__main__":
    main()
